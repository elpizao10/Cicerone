package controller;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import model.User;

public class UserDAOImpl implements UserDAO {
	
	/** La query per l'inserimento di un nuovo utente */
    private static final String CREATE_USER = "INSERT INTO user (nome, cognome, sesso, dataNascita, email, psw, biografia, foto, telefono) VALUES (?,?,?,?,?,MD5(?),?,?,?)";
    /** La query per la lettura di un singolo utente. */
    private static final String READ_USER = "SELECT id, nome, cognome, sesso, dataNascita, email, biografia, foto, telefono FROM user WHERE email = ?";
    /** La query per la lettura di un singolo utente dall'id. */
    private static final String READ_USER_ID = "SELECT id, nome, cognome, sesso, dataNascita, email, biografia, foto, telefono FROM user WHERE id = ?";
    /** La query per la verifica dell'utente */
    private static final String VERIFICA_USER = "SELECT COUNT(*) FROM user WHERE email = ? AND psw=MD5(?)";
    /** La query per la verifica dell'utente by email */
    private static final String VERIFICA_USER_BY_EMAIL = "SELECT COUNT(*) FROM user WHERE email = ?";
    /** La query per la lettura di tutti i utente. */
    private static final String READ_ALL_USER = "SELECT id, nome, cognome, sesso, dataNascita, email, biografia, foto, telefono FROM user";
    /** La query per l'aggiornamento di un singolo utente. */
    private static final String UPDATE_USER = "UPDATE user SET psw=MD5(?), biografia=?, foto=?, telefono=?  WHERE email = ?";
    /** La query per la cancellazione di un singolo utente. */
    private static final String DELETE_USER = "DELETE FROM user WHERE id = ?";
 
	public List getAllUser() {
 
		List user_list = new ArrayList();
		User user = null;
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();            
            preparedStatement = conn.prepareStatement(READ_ALL_USER);
            preparedStatement.execute();
            result = preparedStatement.getResultSet();
 
            while (result.next()) {            	
            	user = new User();
            	user.setId(result.getInt(1));
            	user.setNome(result.getString(2));
            	user.setCognome(result.getString(3));
            	user.setSesso(result.getString(4));
            	user.setDataNascita(result.getDate(5));
            	user.setEmail(result.getString(6));
            	user.setBiografia(result.getString(7));
            	user.setFoto(result.getString(8));
            	user.setTelefono(result.getString(9));
            	
            	user_list.add(user);
            }     
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
        
        return user_list;
	}
 
	public User getUser(String email) {
		
		User user= null;
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();
            preparedStatement = conn.prepareStatement(READ_USER);
            preparedStatement.setString(1, email);
            preparedStatement.execute();
            result = preparedStatement.getResultSet();
 
            if (result.next() && result != null) {
                user = new User();
            	user.setId(result.getInt(1));
            	user.setNome(result.getString(2));
            	user.setCognome(result.getString(3));
            	user.setSesso(result.getString(4));
            	user.setDataNascita(result.getDate(5));
            	user.setEmail(result.getString(6));
            	user.setBiografia(result.getString(7));
            	user.setFoto(result.getString(8));
            	user.setTelefono(result.getString(9));
            } 
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
 
        return user;
	}
	
	
	public int verifyUser(String email, String psw) { //public classe pubblica visibile da altre classi del progetto, int il tipo di dato che la classe deve restituire
                                                      //verifyUser � il nome dell classe, nelle parantesi tonde vanno messi i parametri in input che a sua volta vengono chiamati dall'html		
		int numeroUtenti = 0;
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();
            preparedStatement = conn.prepareStatement(VERIFICA_USER);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, psw);
            preparedStatement.execute();
            result = preparedStatement.getResultSet();
 
            if (result.next() && result != null) {
            	numeroUtenti=result.getInt(1);  
            } 
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
 
        return numeroUtenti;
	}
	
	public int verifyUserByEmail(String email) { //public classe pubblica visibile da altre classi del progetto, int il tipo di dato che la classe deve restituire
		        		//verifyUser � il nome dell classe, nelle parantesi tonde vanno messi i parametri in input che a sua volta vengono chiamati dall'html		
		int numeroUtenti = 0;
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		try {
			conn = DAO.createConnection();
			preparedStatement = conn.prepareStatement(VERIFICA_USER_BY_EMAIL);
			preparedStatement.setString(1, email);
			preparedStatement.execute();
			result = preparedStatement.getResultSet();
			
			if (result.next() && result != null) {
				numeroUtenti=result.getInt(1);  
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				result.close();
			} catch (Exception rse) {
				rse.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (Exception sse) {
				sse.printStackTrace();
			}
			try {
				conn.close();
			} catch (Exception cse) {
				cse.printStackTrace();
			}
		}
	
		return numeroUtenti;
	}
	
	public int createUser(User user) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();
            preparedStatement = conn.prepareStatement(CREATE_USER, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, user.getNome()); //1 significa il primo punto interrogativo della query
            preparedStatement.setString(2, user.getCognome());
            preparedStatement.setString(3, user.getSesso());
            preparedStatement.setTimestamp(4, new Timestamp(user.getDataNascita().getTime()));
            preparedStatement.setString(5, user.getEmail());
            preparedStatement.setString(6, user.getPsw());
            preparedStatement.setString(7, user.getBiografia());
            preparedStatement.setString(8, user.getFoto());
            preparedStatement.setString(9, user.getTelefono());
            preparedStatement.execute();
            result = preparedStatement.getGeneratedKeys();
 
            if (result.next() && result != null) {
                return result.getInt(1);
            } else {
                return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
 
        return -1;
    }
		
 
	public boolean updateUser(User user) {
		
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        try {
        	conn = DAO.createConnection();
            preparedStatement = conn.prepareStatement(UPDATE_USER);
            preparedStatement.setString(1, user.getPsw());
            preparedStatement.setString(2, user.getBiografia());
            preparedStatement.setString(3, user.getFoto());
            preparedStatement.setString(4, user.getTelefono());
            preparedStatement.setString(5, user.getEmail());
            
            preparedStatement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
        return false;
	}
 
	public boolean deleteUser(User user) {
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        try {
            conn = DAO.createConnection();
            preparedStatement = conn.prepareStatement(DELETE_USER);
            preparedStatement.setString(1, user.getEmail());
            preparedStatement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
        return false;
	}

	@Override
	public User getUserById(String userID) {
		
		User user= null;
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();
            preparedStatement = conn.prepareStatement(READ_USER_ID);
            preparedStatement.setInt(1, Integer.parseInt(userID));
            preparedStatement.execute();
            result = preparedStatement.getResultSet();
 
            if (result.next() && result != null) {
                user = new User();
            	user.setId(result.getInt(1));
            	user.setNome(result.getString(2));
            	user.setCognome(result.getString(3));
            	user.setSesso(result.getString(4));
            	user.setDataNascita(result.getDate(5));
            	user.setEmail(result.getString(6));
            	user.setBiografia(result.getString(7));
            	user.setFoto(result.getString(8));
            	user.setTelefono(result.getString(9));
            } 
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
 
        return user;
		
		
	}

	@Override
	public boolean deleteUser(int id) {
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        try {
            conn = DAO.createConnection();
            preparedStatement = conn.prepareStatement(DELETE_USER);
            preparedStatement.setInt(1, id);
            preparedStatement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
        return false;
	}
}
