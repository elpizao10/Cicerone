package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DAO  extends DAOFactory {
	/** la classe driver */
    public static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    /** L'url al database */
    public static final String DBURL = "jdbc:mysql://localhost:3306/";
    
    public static final String DBNAME ="cicerone";
    public static final String LEGACY ="?useLegacyDatetimeCode=false&serverTimezone=UTC";
    
    /** Lo username per le operazioni sul DB  */
    public static final String USER = "root";
    /** La password per le operazioni sul DB */
    public static final String PASS = "1234";
    
    /**
     * Metodo per creare una connessione sul DB MySQL
     * 
     * @return l'oggetto Connection.
     */
    public static Connection createConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DBURL +DBNAME+LEGACY, USER, PASS);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
        	e.printStackTrace();
        }
        return conn;
    }
    
	public UserDAO getUserDAO() {
		return new UserDAOImpl();
	}

	@Override
	public ItinerarioDAO getItinerarioDAO() {
		// TODO Auto-generated method stub
		return new ItineraDAOImpl();
	}
	
}
