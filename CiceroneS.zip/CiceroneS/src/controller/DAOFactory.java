package controller;

public abstract class DAOFactory {

	 /** Membro statico per la factory MySQL */
   public static final int MYSQL = 0;  
   /** Membro statico per la factory Oracle */
   public static final int ORACLE = 1;

   /** Metodo statico per UserDAO */
   public abstract UserDAO getUserDAO();
   
   /**Metodo statico per ItinerarioDAO*/
   public abstract ItinerarioDAO getItinerarioDAO();
   
   public static DAO getDAOFactory(int database) {
       switch (database) {
       case MYSQL:
           return new DAO();
       default:
           return null;
       }
   }
}
