package controller;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import model.Itinerario;
import model.Pair;
import model.User;

public class ItineraDAOImpl implements ItinerarioDAO {
	
	/** La query per l'inserimento di un nuovo itinerario */
    private static final String CREATE_ITINERARIO = "INSERT INTO itinerario (descrizione, importo, durata, numero_max, costi_extra, difficolta, allegato, link, lingua, tipologia, pagamento, luogo, data, id_autore) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    /** La query per l'inserimento di una nuova prenotazione */
    private static final String CREATE_PRENOTAZIONE = "INSERT INTO prenotazione (id_Itinerario, id_User) VALUES (?,?)";
    private static final String DECURTAZIONE = "UPDATE itinerario set numero_max = numero_max-1 where id=? and numero_max>0;";
    private static final String INCREMENTO = "UPDATE itinerario set numero_max = numero_max+1 where id=?;";
    
    /** La query per la cancellazione di una prenotazione */
    private static final String DELETE_PRENOTAZIONE = "DELETE FROM prenotazione where id_Itinerario = ? and id_User=?;";
    
    private static final String FEEDBACK = "UPDATE prenotazione set feedback = ? where id_User=? and id_Itinerario=?;";
    
    /** La query per la lettura di un singolo itinerario. */
    private static final String READ_ITINERARIO = "SELECT id, descrizione, id_autore, importo, durata, numero_max, costi_extra, difficolta, allegato, link, lingua, tipologia, pagamento, luogo, data FROM itinerario WHERE id = ?";
    /** La query per la verifica dell'itinerario */
    private static final String VERIFICA_ITINERARIO = "SELECT COUNT(*) FROM itinerario WHERE descrizione = ?";
    /** La query per la verifica dell'utente by id */
    private static final String VERIFICA_USER_BY_ID_AUTORE = "SELECT COUNT(*) FROM itinerario WHERE id_autore = ?";
    /** La query per la lettura di tutti i utente. */
    private static final String READ_ALL_ITINERARIO = "SELECT * FROM itinerario";
    /** La query per la lettura degli itinerari per specifico ID utente. */
    private static final String READ_MY_ITINERARIO = "SELECT id, descrizione, id_autore, importo, durata, numero_max, costi_extra, difficolta, allegato, link, lingua, tipologia, pagamento, luogo, data FROM itinerario where id_autore = ?";
    /** La query per la lettura degli itinerari a partire da oggi degli altri utente. */
    private static final String READ_ITINERARIO_FROM_TODAY = "SELECT itinerario.id,itinerario.descrizione,itinerario.id_autore,itinerario.importo,itinerario.durata,itinerario.numero_max,itinerario.costi_extra,itinerario.difficolta,itinerario.allegato,itinerario.link,itinerario.lingua,itinerario.tipologia,itinerario.pagamento,itinerario.luogo,itinerario.data,user.nome,user.cognome,user.email from itinerario inner join user on user.id=itinerario.id_autore where id_autore <> ? and data >= CURDATE() and itinerario.id not in (select prenotazione.id_Itinerario from prenotazione where prenotazione.id_User = ?) and itinerario.numero_max>0;";
    /** La query per la lettura degli itinerari prenotati. */
    private static final String READ_ITINERARIO_PRENOTATI = "SELECT itinerario.id,itinerario.descrizione,itinerario.id_autore,itinerario.importo,itinerario.durata,itinerario.numero_max,itinerario.costi_extra,itinerario.difficolta,itinerario.allegato,itinerario.link,itinerario.lingua,itinerario.tipologia,itinerario.pagamento,itinerario.luogo,itinerario.data,user.nome,user.cognome,user.email from itinerario inner join user on user.id=itinerario.id_autore where id_autore <> ? and itinerario.id in (select prenotazione.id_Itinerario from prenotazione where prenotazione.id_User = ?);";
    
 
	public List getAllItinera() {
 
		List<Itinerario> itinera_list = new ArrayList();
		
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();            
            preparedStatement = conn.prepareStatement(READ_ALL_ITINERARIO);
            preparedStatement.execute();
            result = preparedStatement.getResultSet();
 
            while (result.next()) {   
            	Itinerario itinerario = new Itinerario();
            	
            	itinerario.setId(result.getInt(1));
            	itinerario.setDescrizione(result.getString(2));
            	itinerario.setId_autore(result.getInt(3));
            	itinerario.setImporto(result.getInt(4));
            	itinerario.setDurata(result.getInt(5));
            	itinerario.setNumero_max(result.getInt(6));
            	itinerario.setCosti_extra(result.getInt(7));
            	itinerario.setDifficolt�(result.getString(8));
            	itinerario.setAllegato(result.getString(9));
            	itinerario.setLink(result.getString(10));
            	itinerario.setLingua(result.getString(11));
            	itinerario.setTipologia(result.getString(12));
            	itinerario.setPagamento(result.getString(13));
            	itinerario.setLuogo(result.getString(14));
            	itinerario.setData(result.getDate(15));
            	
            	
            	
            	itinera_list.add(itinerario);
            }     
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
        
        return itinera_list;
	}
 
	public Itinerario getItinerario(String itinerioId) {
		
		Itinerario itinerario = null;
		
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();            
            preparedStatement = conn.prepareStatement(READ_ITINERARIO);
            preparedStatement.setInt(1, Integer.parseInt(itinerioId));
            preparedStatement.execute();
            result = preparedStatement.getResultSet();
            
            if (result.next() && result != null) {
            	itinerario = new Itinerario();
            	
	        	itinerario.setId(result.getInt(1));
	        	itinerario.setDescrizione(result.getString(2));
	        	itinerario.setId_autore(result.getInt(3));
	        	itinerario.setImporto(result.getInt(4));
	        	itinerario.setDurata(result.getInt(5));
	        	itinerario.setNumero_max(result.getInt(6));
	        	itinerario.setCosti_extra(result.getInt(7));
	        	itinerario.setDifficolt�(result.getString(8));
	        	itinerario.setAllegato(result.getString(9));
	        	itinerario.setLink(result.getString(10));
	        	itinerario.setLingua(result.getString(11));
	        	itinerario.setTipologia(result.getString(12));
	        	itinerario.setPagamento(result.getString(13));
	        	itinerario.setLuogo(result.getString(14));
	        	itinerario.setData(result.getDate(15));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
		
        return itinerario;
	}
	
	
	public int verifyItinerario(String descrizione) { //public classe pubblica visibile da altre classi del progetto, int il tipo di dato che la classe deve restituire
                                                      //verifyUser � il nome dell classe, nelle parantesi tonde vanno messi i parametri in input che a sua volta vengono chiamati dall'html		
		int numeroItinerario = 0;
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();
            preparedStatement = conn.prepareStatement(VERIFICA_ITINERARIO);
            preparedStatement.setString(1, descrizione);
            preparedStatement.execute();
            result = preparedStatement.getResultSet();
 
            if (result.next() && result != null) {
            	numeroItinerario=result.getInt(1);  
            } 
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
 
        return numeroItinerario;
	}
	
	public int createItinerario(Itinerario itinerario) {
        Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();
            preparedStatement = conn.prepareStatement(CREATE_ITINERARIO, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, itinerario.getDescrizione()); //1 significa il primo punto interrogativo della query
            preparedStatement.setInt(2, itinerario.getImporto());
            preparedStatement.setInt(3, itinerario.getDurata());
            preparedStatement.setInt(4, itinerario.getNumero_max());
            preparedStatement.setInt(5, itinerario.getCosti_extra());
            preparedStatement.setString(6, itinerario.getDifficolt�());
            preparedStatement.setString(7, itinerario.getAllegato());
            preparedStatement.setString(8, itinerario.getLink());
            preparedStatement.setString(9, itinerario.getLingua());
            preparedStatement.setString(10, itinerario.getTipologia());
            preparedStatement.setString(11, itinerario.getPagamento());
            preparedStatement.setString(12, itinerario.getLuogo());
            preparedStatement.setTimestamp(13, new Timestamp(itinerario.getData().getTime()));
            preparedStatement.setInt(14, itinerario.getId_autore());
            
            preparedStatement.execute();
            result = preparedStatement.getGeneratedKeys();
 
            if (result.next() && result != null) {
                return result.getInt(1);
            } else {
                return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
 
        return -1;
    }

	@Override
	public List listMyItinerari(int id_autore) {
		List<Itinerario> itinera_list = new ArrayList();
		
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();            
            preparedStatement = conn.prepareStatement(READ_MY_ITINERARIO);
            preparedStatement.setInt(1, id_autore);
            preparedStatement.execute();
            result = preparedStatement.getResultSet();
 
            while (result.next()) {   
            	Itinerario itinerario = new Itinerario();
            	
            	itinerario.setId(result.getInt(1));
            	itinerario.setDescrizione(result.getString(2));
            	itinerario.setId_autore(result.getInt(3));
            	itinerario.setImporto(result.getInt(4));
            	itinerario.setDurata(result.getInt(5));
            	itinerario.setNumero_max(result.getInt(6));
            	itinerario.setCosti_extra(result.getInt(7));
            	itinerario.setDifficolt�(result.getString(8));
            	itinerario.setAllegato(result.getString(9));
            	itinerario.setLink(result.getString(10));
            	itinerario.setLingua(result.getString(11));
            	itinerario.setTipologia(result.getString(12));
            	itinerario.setPagamento(result.getString(13));
            	itinerario.setLuogo(result.getString(14));
            	itinerario.setData(result.getDate(15));
            	
            	
            	
            	itinera_list.add(itinerario);
            }     
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
		
        return itinera_list;
	}
	
	
	@Override
	public Pair listItinerariFromToday(int id_autore) {
		List<Itinerario> itinera_list = new ArrayList();
		List<User> user_listI = new ArrayList();
		
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();            
            preparedStatement = conn.prepareStatement(READ_ITINERARIO_FROM_TODAY);
            preparedStatement.setInt(1, id_autore);
            preparedStatement.setInt(2, id_autore);
            preparedStatement.execute();
            result = preparedStatement.getResultSet();
 
            while (result.next()) {   
            	Itinerario itinerario = new Itinerario();
            	User user = new User();
            	
            	
            	itinerario.setId(result.getInt(1));
            	itinerario.setDescrizione(result.getString(2));
            	itinerario.setId_autore(result.getInt(3));
            	itinerario.setImporto(result.getInt(4));
            	itinerario.setDurata(result.getInt(5));
            	itinerario.setNumero_max(result.getInt(6));
            	itinerario.setCosti_extra(result.getInt(7));
            	itinerario.setDifficolt�(result.getString(8));
            	itinerario.setAllegato(result.getString(9));
            	itinerario.setLink(result.getString(10));
            	itinerario.setLingua(result.getString(11));
            	itinerario.setTipologia(result.getString(12));
            	itinerario.setPagamento(result.getString(13));
            	itinerario.setLuogo(result.getString(14));
            	itinerario.setData(result.getDate(15));
            	
            	user.setNome(result.getString(16));
            	user.setCognome(result.getString(17));
            	user.setEmail(result.getString(18));
            	
            	
            	user_listI.add(user);
            	itinera_list.add(itinerario);
            }     
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
		
        return new Pair(itinera_list, user_listI);
	}

	@Override
	public int createPrenotazione(int idItinerario, int idUser) {
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();
            preparedStatement = conn.prepareStatement(CREATE_PRENOTAZIONE, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setInt(1, idItinerario); //1 significa il primo punto interrogativo della query
            preparedStatement.setInt(2, idUser);
            
            preparedStatement.execute();
            result = preparedStatement.getGeneratedKeys();
 
            if (result.next() && result != null) {
                preparedStatement = conn.prepareStatement(DECURTAZIONE);
                preparedStatement.setInt(1, idItinerario); //1 significa il primo punto interrogativo della query
                preparedStatement.execute();
                
                return result.getInt(1);
            } else {
                return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
 
        return -1;
	}

	@Override
	public Pair listItinerariPrenotati(int id_user) {
		List<Itinerario> itinera_list = new ArrayList();
		List<User> user_listI = new ArrayList();
		
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();            
            preparedStatement = conn.prepareStatement(READ_ITINERARIO_PRENOTATI);
            preparedStatement.setInt(1, id_user);
            preparedStatement.setInt(2, id_user);
            preparedStatement.execute();
            result = preparedStatement.getResultSet();
 
            while (result.next()) {   
            	Itinerario itinerario = new Itinerario();
            	User user = new User();
            	
            	
            	itinerario.setId(result.getInt(1));
            	itinerario.setDescrizione(result.getString(2));
            	itinerario.setId_autore(result.getInt(3));
            	itinerario.setImporto(result.getInt(4));
            	itinerario.setDurata(result.getInt(5));
            	itinerario.setNumero_max(result.getInt(6));
            	itinerario.setCosti_extra(result.getInt(7));
            	itinerario.setDifficolt�(result.getString(8));
            	itinerario.setAllegato(result.getString(9));
            	itinerario.setLink(result.getString(10));
            	itinerario.setLingua(result.getString(11));
            	itinerario.setTipologia(result.getString(12));
            	itinerario.setPagamento(result.getString(13));
            	itinerario.setLuogo(result.getString(14));
            	itinerario.setData(result.getDate(15));
            	
            	user.setNome(result.getString(16));
            	user.setCognome(result.getString(17));
            	user.setEmail(result.getString(18));
            	
            	
            	user_listI.add(user);
            	itinera_list.add(itinerario);
            }     
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                result.close();
            } catch (Exception rse) {
                rse.printStackTrace();
            }
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
		
        return new Pair(itinera_list, user_listI);
	}

	@Override
	public int deletePrenotazione(int idItinerario, int idUser) {		
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();
            preparedStatement = conn.prepareStatement(DELETE_PRENOTAZIONE);
            preparedStatement.setInt(1, idItinerario); //1 significa il primo punto interrogativo della query
            preparedStatement.setInt(2, idUser);
            
            preparedStatement.executeUpdate();
            
            preparedStatement = conn.prepareStatement(INCREMENTO);
            preparedStatement.setInt(1, idItinerario); //1 significa il primo punto interrogativo della query
            preparedStatement.execute();
            
            return 1;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
 
        return -1;
	}

	@Override
	public int updateFeedback(String itinerioId, int id, String feedback) {
		Connection conn = null;
        PreparedStatement preparedStatement = null;
        ResultSet result = null;
        try {
            conn = DAO.createConnection();
            preparedStatement = conn.prepareStatement(FEEDBACK);
            preparedStatement.setString(1, feedback); //1 significa il primo punto interrogativo della query
            preparedStatement.setInt(2, id);
            preparedStatement.setInt(3, Integer.parseInt(itinerioId));
            
            preparedStatement.execute();
            
            return 1;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                preparedStatement.close();
            } catch (Exception sse) {
                sse.printStackTrace();
            }
            try {
                conn.close();
            } catch (Exception cse) {
                cse.printStackTrace();
            }
        }
 
        return -1;
	}
}
		
 
	
	