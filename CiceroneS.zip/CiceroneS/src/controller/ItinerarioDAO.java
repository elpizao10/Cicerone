package controller;
import java.util.List;

import model.Itinerario;
import model.Pair;
import model.User;

public interface  ItinerarioDAO {
	
	public List getAllItinera();
	
	/** Recupera un oggetto Itinerario esistente a partire della descrizione. */
	public Itinerario getItinerario(String itinerioId);
	
	/** Crea un oggetto Itinerario e restituisce l'id. */
	public int createItinerario(Itinerario itinerario);
	
	/** Verifica un oggetto Itinerario esistente a partire dall'id e dell'id_autore. */
	public int verifyItinerario(String descrizione);
	
	/** Verifica un oggetto Itinerario esistente a partire dall'id e dell'id_autore. */
	public List listMyItinerari(int id_autore);
	
	public Pair listItinerariFromToday(int id_autore);
	
	public Pair listItinerariPrenotati(int id_user);
	/** Crea un oggetto Prenotazione e restituisce l'id. */
	public int createPrenotazione(int idItinerario, int idUser);
	/** Cancella un oggetto Prenotazione. */
	public int deletePrenotazione(int idItinerario, int idUser);

	public int updateFeedback(String itinerioId, int id, String feedback);
}
