package controller;

import java.util.List;

import model.User;

public interface  UserDAO {
	public List getAllUser();
	
	/** Recupera un oggetto User esistente a partire dall'id. */
	public User getUser(String email);
	
	public User getUserById(String userID);
	
	/** Crea un oggetto User e restituisce l'id. */
	public int createUser(User user);
	
	/** Verifica un oggetto User esistente a partire dall'email e psw. */
	public int verifyUser(String user, String psw);
	
	/** Verifica un oggetto User esistente a partire dall'email. */
	public int verifyUserByEmail(String user);
	
	/** Aggiorna un oggetto User esistente. */
	public boolean updateUser(User user);
	
	/** Cancella un oggetto User esistente. */
	public boolean deleteUser(User user);

	public boolean deleteUser(int id);
}
