package model;

import java.io.InputStream;
import java.sql.Blob;
import java.util.Date;

public class User {
	private int id;
	private String email;
	private String psw;
	private String nome;
	private String cognome;
	private String sesso;
	private Date dataNascita;
	private String telefono;
	private String biografia;
	private String foto;
	
	public User() {}
	
	public User(int id, String email, String psw, String nome, String cognome, String sesso, Date dataNascita, String telefono, String biografia, String foto) {
		this.id = id;
		this.email=email;
		this.psw=psw;
		this.nome=nome;
		this.cognome=cognome;
		this.sesso=sesso;
		this.dataNascita=dataNascita;
		this.telefono=telefono;
		this.biografia=biografia;
		this.foto=foto;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBiografia() {
		return biografia;
	}

	public void setBiografia(String biografia) {
		this.biografia = biografia;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String inputStream) {
		this.foto = inputStream;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public Date getDataNascita() {
		return dataNascita;
	}

	public void setDataNascita(Date dataNascita) {
		this.dataNascita = dataNascita;
	}

	public void setEmail(String email) {
		this.email=email;
	}
	public String getEmail() {
		return email;
	}
	
	public void setPsw(String psw) {
		this.psw=psw;
	}
	public String getPsw() {
		return psw;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}


	public String getSesso() {
		return sesso;
	}

	public void setSesso(String sesso) {
		this.sesso = sesso;
	}

	

}
