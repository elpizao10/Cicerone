package model;

import java.io.InputStream;
import java.util.Date;

public class Itinerario {
	private int id;
	private String descrizione;
	private int id_autore;
	private int importo;
	private int durata;
	private int numero_max;
	private int costi_extra;
	private String difficolt�;
	private String allegato;
	private String link;
	private String lingua;
	private String tipologia;
	private String pagamento;
	private String luogo;
	private Date data;
	
	
	public Itinerario() {}
	
	public Itinerario(int id, String descrizione,int id_autore, int importo, int durata, int numero_max, int costi_extra, String difficolt�, String allegato, String link, String lingua, String tipologia, String pagamento, String luogo, Date data) {
		this.id=id;
		this.descrizione=descrizione;
		this.id_autore=id_autore;
		this.importo=importo;
		this.durata=durata;
		this.numero_max=numero_max;
		this.costi_extra=costi_extra;
		this.difficolt�=difficolt�;
		this.allegato=allegato;
		this.link=link;
		this.lingua=lingua;
		this.tipologia=tipologia;
		this.pagamento=pagamento;
		this.luogo=luogo;
		this.data=data;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public int getId_autore() {
		return id_autore;
	}

	public void setId_autore(int id_autore) {
		this.id_autore = id_autore;
	}

	public int getImporto() {
		return importo;
	}

	public void setImporto(int importo) {
		this.importo = importo;
	}

	public int getDurata() {
		return durata;
	}

	public void setDurata(int durata) {
		this.durata = durata;
	}

	public int getNumero_max() {
		return numero_max;
	}

	public void setNumero_max(int numero_max) {
		this.numero_max = numero_max;
	}

	public int getCosti_extra() {
		return costi_extra;
	}

	public void setCosti_extra(int costi_extra) {
		this.costi_extra = costi_extra;
	}

	public String getDifficolt�() {
		return difficolt�;
	}

	public void setDifficolt�(String difficolt�) {
		this.difficolt� = difficolt�;
	}

	public String getAllegato() {
		return allegato;
	}

	public void setAllegato(String allegato) {
		this.allegato = allegato;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getLingua() {
		return lingua;
	}

	public void setLingua(String lingua) {
		this.lingua = lingua;
	}

	public String getTipologia() {
		return tipologia;
	}

	public void setTipologia(String tipologia) {
		this.tipologia = tipologia;
	}

	public String getPagamento() {
		return pagamento;
	}

	public void setPagamento(String pagamento) {
		this.pagamento = pagamento;
	}

	public String getLuogo() {
		return luogo;
	}

	public void setLuogo(String luogo) {
		this.luogo = luogo;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	
}


