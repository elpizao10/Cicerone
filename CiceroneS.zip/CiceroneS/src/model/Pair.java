package model;

import java.util.ArrayList;
import java.util.List;

public class Pair {
	private List<Itinerario> itinera_list = new ArrayList();
	private List<User> user_listI = new ArrayList();

    public Pair(List<Itinerario> itinera_list, List<User> user_listI) {
        this.itinera_list = itinera_list;
        this.user_listI = user_listI;
    }

	public List<Itinerario> getItinera_list() {
		return itinera_list;
	}

	public void setItinera_list(List<Itinerario> itinera_list) {
		this.itinera_list = itinera_list;
	}

	public List<User> getUser_listI() {
		return user_listI;
	}

	public void setUser_listI(List<User> user_listI) {
		this.user_listI = user_listI;
	}
    
    
}
