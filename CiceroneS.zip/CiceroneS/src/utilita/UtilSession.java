package utilita;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import controller.DAOFactory;
import controller.UserDAO;
import model.User;

public class UtilSession {
	
	public static HttpServletRequest setSession(HttpServletRequest request, ServletContext servletContext) throws IOException {
		String email = null;
    	
    	Cookie[] cookies = request.getCookies();
	    if (cookies != null) {
	    	 for (Cookie cookie : cookies) {
	    	   if (cookie.getName().equals("user")) {
	    		   email = cookie.getValue();
	    	    }
	    	  }
	    	}
	    if(email!=null) {
		    DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
			UserDAO userDAO = mysqlFactory.getUserDAO();
		    User user = userDAO.getUser(email);
			    
		    String base64Image = user.getFoto();
	        
	        request.setAttribute("profile", base64Image);
		    request.setAttribute("user", user);
	    }
		return request;
	}
}
