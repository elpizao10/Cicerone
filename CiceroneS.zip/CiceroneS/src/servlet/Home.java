package servlet;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.Base64;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;

import controller.DAO;
import controller.DAOFactory;
import controller.UserDAO;
import model.User;
import utilita.UtilSession;

@WebServlet("/Home")
public class Home extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Home() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	request = UtilSession.setSession(request, getServletContext());
    	
	    RequestDispatcher dispatcher;
	    dispatcher = getServletContext().getRequestDispatcher("/Home.jsp");
	    dispatcher.forward(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
	    String psw = request.getParameter("psw");
	    
	    DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		UserDAO userDAO = mysqlFactory.getUserDAO();
		int ok = userDAO.verifyUser(email, psw);
	    
		if(ok>0) {
			User user = userDAO.getUser(email);
		    
		    Cookie userCookie = new Cookie("user", user.getEmail());
		    //userCookie.setMaxAge(60*60*24*5);
		    response.addCookie(userCookie);
		    
			String base64Image = user.getFoto();
            
            request.setAttribute("profile", base64Image);
		    request.setAttribute("user", user);
		   
		    RequestDispatcher dispatcher;
		    dispatcher = getServletContext().getRequestDispatcher("/Home.jsp");
		    dispatcher.forward(request,response);
		} else {
			String mesg ="Email o password errati";
	    	request.setAttribute("jsalert", mesg);
		    
		    RequestDispatcher dispatcher;
		    dispatcher = getServletContext().getRequestDispatcher("/login.jsp");
		    dispatcher.forward(request,response);
		}
	}

}
