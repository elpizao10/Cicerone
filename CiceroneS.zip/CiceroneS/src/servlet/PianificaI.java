package servlet;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import controller.DAOFactory;
import controller.ItinerarioDAO;
import controller.UserDAO;
import controller.UserDAOImpl;
import model.Itinerario;
import model.User;
import utilita.UtilSession;

@MultipartConfig
@WebServlet("/PianificaI")
public class PianificaI extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public PianificaI() {
        super();
        
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request = UtilSession.setSession(request, getServletContext());
	   
	    RequestDispatcher dispatcher;
	    dispatcher = getServletContext().getRequestDispatcher("/pianificaI.jsp");
	    dispatcher.forward(request,response);
	}
    

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request = UtilSession.setSession(request, getServletContext());
		User user = (User) request.getAttribute("user");
		
		String descrizione = request.getParameter("descrizione");
		int importo = Integer.parseInt(request.getParameter("importo"));
		int durata = Integer.parseInt(request.getParameter("durata"));
		int numero_max = Integer.parseInt(request.getParameter("numero_max"));
		int costi_extra = Integer.parseInt(request.getParameter("costi_extra"));
	    String difficolt� = request.getParameter("difficolt�");
	    String link = request.getParameter("link");
	    String lingua = request.getParameter("lingua");
	    String tipologia = request.getParameter("tipologia");
	    String pagamento = request.getParameter("pagamento");
	    String luogo = request.getParameter("luogo");
	    String data = request.getParameter("data");
	    String allegato = request.getParameter("foto64");
	    
	    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	    Date parsedDate = null;
		try {
			parsedDate = format.parse(data);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
		    DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		    ItinerarioDAO itinerarioDAO = mysqlFactory.getItinerarioDAO();
		    int count = itinerarioDAO.verifyItinerario(descrizione);
		    
		    if(count == 0) {
		    	
		    	Itinerario itinerario = new Itinerario();
		    	itinerario.setDescrizione(descrizione);
		    	itinerario.setImporto(importo);
		    	itinerario.setDurata(durata);
		    	itinerario.setNumero_max(numero_max);
		    	itinerario.setCosti_extra(costi_extra);
		    	itinerario.setDifficolt�(difficolt�);
		    	itinerario.setAllegato(allegato);
		    	itinerario.setLink(link);
		    	itinerario.setLingua(lingua);
		    	itinerario.setTipologia(tipologia);
		    	itinerario.setPagamento(pagamento);
		    	itinerario.setLuogo(luogo);
		    	itinerario.setData(parsedDate);
		    	itinerario.setId_autore(user.getId());
			    
		    	int ok = itinerarioDAO.createItinerario(itinerario);
		    	if (ok>0) {
		    		String mesg ="Attivit� creata correttamente.";
		    		request.setAttribute("jsalert", mesg);
		    		request.setAttribute("type", "success");
		    		
				    RequestDispatcher dispatcher;
				    dispatcher = getServletContext().getRequestDispatcher("/pianificaI.jsp");
				    dispatcher.forward(request,response);
		    	}else {
		    		String mesg ="Problema nell'inserimento dei dati";
		    		request.setAttribute("jsalert", mesg);
		    		request.setAttribute("type", "error");
		    		
				    RequestDispatcher dispatcher;
				    dispatcher = getServletContext().getRequestDispatcher("/pianificaI.jsp");
				    dispatcher.forward(request,response);
		    	}
		    } else {
		    	String mesg ="Attivit� gi� presente";
		    	request.setAttribute("jsalert", mesg);
		    	request.setAttribute("type", "error");
			    
			    RequestDispatcher dispatcher;
			    dispatcher = getServletContext().getRequestDispatcher("/pianificaI.jsp");
			    dispatcher.forward(request,response);
		    }
	    }
	}


