package servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import controller.DAOFactory;
import controller.UserDAO;
import controller.UserDAOImpl;
import model.User;

@MultipartConfig
@WebServlet("/Registrazione")
public class Registrazione extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Registrazione() {
        super();
        
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nome = request.getParameter("nome");
		String cognome = request.getParameter("cognome");
		String email = request.getParameter("email");
	    String psw = request.getParameter("psw");
	    String rpsw = request.getParameter("rpsw");
	    String sesso = request.getParameter("sesso");
	    String dataNascita = request.getParameter("dataNascita");
	    String biografia = request.getParameter("biografia");
	    String inputStream = request.getParameter("foto64");
	    
	    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	    Date parsedDate = null;
		try {
			parsedDate = format.parse(dataNascita);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String telefono = request.getParameter("telefono");
	    
	    
	    if(psw.equals(rpsw)) {
		    DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
			UserDAO userDAO = mysqlFactory.getUserDAO();
		    int count = userDAO.verifyUserByEmail(email);
		    if(count == 0) {
		    	User user = new User();
		    	user.setNome(nome);
		    	user.setCognome(cognome);
			    user.setEmail(email);
			    user.setPsw(psw);
			    user.setSesso(sesso);
			    user.setDataNascita(parsedDate);
			    user.setTelefono(telefono);
			    user.setBiografia(biografia);
			    user.setFoto(inputStream);
			    
		    	int ok = userDAO.createUser(user);
		    	if (ok>0) {
		    		String mesg ="Utente creato correttamente. Effettua il Login !";
		    		request.setAttribute("jsalert", mesg);
		    		request.setAttribute("type", "success");
		    		
				    RequestDispatcher dispatcher;
				    dispatcher = getServletContext().getRequestDispatcher("/register.jsp");
				    dispatcher.forward(request,response);
		    	}else {
		    		String mesg ="Problema nella registrazione si prega di riprovare";
		    		request.setAttribute("jsalert", mesg);
		    		request.setAttribute("type", "error");
		    		
				    RequestDispatcher dispatcher;
				    dispatcher = getServletContext().getRequestDispatcher("/register.jsp");
				    dispatcher.forward(request,response);
		    	}
		    } else {
		    	String mesg ="Email gi� presente";
		    	request.setAttribute("jsalert", mesg);
		    	request.setAttribute("type", "error");
			    
			    RequestDispatcher dispatcher;
			    dispatcher = getServletContext().getRequestDispatcher("/register.jsp");
			    dispatcher.forward(request,response);
		    }
	    }else {
	    	String mesg ="Le password inserite non corrispondono";
	    	request.setAttribute("jsalert",mesg);
	    	request.setAttribute("type", "error");
	    	
		    RequestDispatcher dispatcher;
		    dispatcher = getServletContext().getRequestDispatcher("/register.jsp");
		    dispatcher.forward(request,response);
	    }
	}

}
