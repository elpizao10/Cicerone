package servlet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.DAOFactory;
import controller.ItinerarioDAO;
import controller.UserDAO;
import model.User;
import utilita.UtilSession;
import model.Itinerario;


@WebServlet("/CreatedI")
public class CreatedI extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CreatedI() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request = UtilSession.setSession(request, getServletContext());
		User user = (User) request.getAttribute("user");

		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
	    ItinerarioDAO itinerarioDAO = mysqlFactory.getItinerarioDAO();
	    List<Itinerario> itinerari = itinerarioDAO.listMyItinerari(user.getId());
	    
	    String tableCreated = "";
	    for(int i=0; i<itinerari.size(); i++) {
	    	Itinerario temp = itinerari.get(i);
	    	
	    	tableCreated = tableCreated+
	    		"<tr>" + 
	    			"<td>"+temp.getDescrizione()+"</td>" + 
	    			"<td>"+temp.getImporto()+"</td>" +
	    			"<td>"+temp.getDurata()+"</td>" +
	    			"<td>"+temp.getData()+"</td>" +
	    			"<td>"+temp.getDifficolt�()+"</td>" + 
	    			"<td>"+temp.getLingua()+"</td>" +
	    		"</tr>";
	    }
        
	    request.setAttribute("tableCreated", tableCreated);
	   
	    RequestDispatcher dispatcher;
	    dispatcher = getServletContext().getRequestDispatcher("/createdI.jsp");
	    dispatcher.forward(request,response);
	}

}
