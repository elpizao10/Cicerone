package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.DAOFactory;
import controller.ItinerarioDAO;
import model.Itinerario;
import model.Pair;
import model.User;
import utilita.UtilSession;

/**
 * Servlet implementation class PrenotatiI
 */
@WebServlet("/PrenotatiI")
public class PrenotatiI extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public PrenotatiI() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request = UtilSession.setSession(request, getServletContext());
		User user = (User) request.getAttribute("user");
		
		String ricercaI = null;
		ricercaI = request.getParameter("ricercaI");

		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
	    ItinerarioDAO itinerarioDAO = mysqlFactory.getItinerarioDAO();
	    Pair itinerari_user = itinerarioDAO.listItinerariPrenotati(user.getId());
	    
	    List<Itinerario> itinerari = itinerari_user.getItinera_list();
	    List<User> users = itinerari_user.getUser_listI();
	    
	    String tableCreated = "";
	    for(int i=0; i<itinerari.size(); i++) {
	    	Itinerario tempI = itinerari.get(i);
	    	User tempU = users.get(i);

	    	tableCreated = tableCreated+
	    		"<tr>" + 
	    			"<td>"+tempI.getDescrizione()+"</td>" + 
	    			"<td>"+tempU.getEmail()+"</td>" +
	    			"<td>"+tempI.getDurata()+" ore </td>" +
	    			"<td>"+tempI.getData()+"</td>" +
	    			"<td>"+tempI.getLuogo()+"</td>" +
	    			"<td>"+tempI.getNumero_max()+"</td>" +
	    			"<td> <center> <a href='./DettagliI?itinerio="+tempI.getId()+"&utenteCreate="+tempU.getEmail()+"&metodo=delete&link=./PrenotatiI'> <i class='fas fa-clipboard-list fa-2x'></i> </a> </center> </td>" +
	    		"</tr>";
	    }
        
	    request.setAttribute("tableCreated", tableCreated);
	    request.setAttribute("defaultS", ricercaI);
	   
	    RequestDispatcher dispatcher;
	    dispatcher = getServletContext().getRequestDispatcher("/prenotatiI.jsp");
	    dispatcher.forward(request,response);
	}
}
