package servlet;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import controller.DAO;
import controller.DAOFactory;
import controller.UserDAO;
import model.User;
import utilita.UtilSession;

@MultipartConfig
@WebServlet("/Profilo")
public class Profilo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Profilo() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request = UtilSession.setSession(request, getServletContext());
		User user = (User) request.getAttribute("user");
        
        String maschio = null;
        String femmina = null;
        
        if(user.getSesso().equalsIgnoreCase("Maschio")) {
        	maschio = "checked";
        } else if (user.getSesso().equalsIgnoreCase("Femmina")) {
        	femmina = "checked";
        }
        
        request.setAttribute("maschio", maschio);
        request.setAttribute("femmina", femmina);
	   
	    RequestDispatcher dispatcher;
	    dispatcher = getServletContext().getRequestDispatcher("/profilo.jsp");
	    dispatcher.forward(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request = UtilSession.setSession(request, getServletContext());
		User user = (User) request.getAttribute("user");
		
		String azione = request.getParameter("submit");
		if(azione.equalsIgnoreCase("aggiorna")) {
		    String psw = request.getParameter("psw");
		    String rpsw = request.getParameter("rpsw");
		    String biografia = request.getParameter("biografia");
		    String inputStream = request.getParameter("foto64");
			String telefono = request.getParameter("telefono");
		    
		    if(psw.isEmpty() || rpsw.isEmpty() || biografia.isEmpty() || telefono.isEmpty()) {
		    	String mesg ="Nessun aggiornamento effettuato. Inserire la password o la biografia o il telefono";
	    		request.setAttribute("jsalert", mesg);
	    		request.setAttribute("type", "warning");
	    		
			    RequestDispatcher dispatcher;
			    dispatcher = getServletContext().getRequestDispatcher("/profilo.jsp");
			    dispatcher.forward(request,response);
		    }else if (!psw.isEmpty() && !rpsw.isEmpty()) {
			    if(psw.equals(rpsw) ) {
				    DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
					UserDAO userDAO2 = mysqlFactory.getUserDAO();
				    	
					User user2 = new User();
					user2.setEmail(user.getEmail());
					user2.setPsw(psw);
					user2.setTelefono(telefono);
					user2.setBiografia(biografia);
					user2.setFoto(inputStream);
					    
			    	boolean ok = userDAO2.updateUser(user2);
			    	if (ok) {
			    		String mesg ="Aggiornamento effettuato correttamente.";
			    		request.setAttribute("jsalert", mesg);
			    		request.setAttribute("type", "success");
			    		
					    RequestDispatcher dispatcher;
					    dispatcher = getServletContext().getRequestDispatcher("/profilo.jsp");
					    dispatcher.forward(request,response);
			    	}else {
			    		String mesg ="Problema nell'aggiornamento dei dati, si prega di riprovare";
			    		request.setAttribute("jsalert", mesg);
			    		request.setAttribute("type", "error");
			    		
					    RequestDispatcher dispatcher;
					    dispatcher = getServletContext().getRequestDispatcher("/profilo.jsp");
					    dispatcher.forward(request,response);
			    	}
			    }else {
			    	String mesg ="Le password inserite non corrispondono";
			    	request.setAttribute("jsalert",mesg);
			    	request.setAttribute("type", "error");
			    	
				    RequestDispatcher dispatcher;
				    dispatcher = getServletContext().getRequestDispatcher("/profilo.jsp");
				    dispatcher.forward(request,response);
			    }
		    }
		} else if(azione.equalsIgnoreCase("delete")) {
			DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
			UserDAO userDAO2 = mysqlFactory.getUserDAO();
			
			boolean ok = userDAO2.deleteUser(user.getId());
	    	if (ok) {
	    		String mesg ="Utente eliminato correttamente. Effettua il logout";
	    		request.setAttribute("jsalert", mesg);
	    		request.setAttribute("type", "success");
	    		
			    RequestDispatcher dispatcher;
			    dispatcher = getServletContext().getRequestDispatcher("/profilo.jsp");
			    dispatcher.forward(request,response);
	    	}else {
	    		String mesg ="Problema nell eliminazione dell utente, si prega di riprovare";
	    		request.setAttribute("jsalert", mesg);
	    		request.setAttribute("type", "error");
	    		
			    RequestDispatcher dispatcher;
			    dispatcher = getServletContext().getRequestDispatcher("/profilo.jsp");
			    dispatcher.forward(request,response);
	    	}
		}
	}

}
