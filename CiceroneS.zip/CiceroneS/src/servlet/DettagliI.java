package servlet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.Base64;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import controller.DAOFactory;
import controller.UserDAO;
import controller.ItinerarioDAO;
import model.Itinerario;
import model.User;
import utilita.UtilSession;

/**
 * Servlet implementation class DettagliI
 */
@WebServlet("/DettagliI")
public class DettagliI extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public DettagliI() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request = UtilSession.setSession(request, getServletContext());
		User user = (User) request.getAttribute("user");
		
		String itinerioId = (String) request.getParameter("itinerio");
		String userEmailItin = (String) request.getParameter("utenteCreate");
		String link = (String) request.getParameter("link");
		
		DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		UserDAO userDAO = mysqlFactory.getUserDAO();
	    User userI = userDAO.getUser(userEmailItin);
	    
	    ItinerarioDAO itinDAO = mysqlFactory.getItinerarioDAO();
	    Itinerario itinerario = itinDAO.getItinerario(itinerioId);
	    
	    String metodo = (String) request.getParameter("metodo");
	    String button ="";

	    if(metodo.equalsIgnoreCase("prenota")) {
	    	button = "<button type='submit' name='button' class=\"btn btn-primary btn-user btn-block\" value='prenota;"+itinerario.getId()+";"+user.getId()+"'> PRENOTA </button>";
	    } else if (metodo.equalsIgnoreCase("delete")) {
	    	button = "<button type='submit' name='button' class=\"btn btn-danger btn-user btn-block\" value='delete;"+itinerario.getId()+";"+user.getId()+"'> CANCELLA </button> "
	    			+ "<a href='#' name='feedback' class=\"btn btn-primary btn-user btn-block\" value='"+itinerario.getId()+";"+user.getId()+"' onclick='feedback();'> LASCIA UN FEEDBACK </a> ";
	    }
	    
	    
	    
	    //prendo il feedback se valorizzato
	    String mesg="";
	    String feedback = "";
	    feedback = (String) request.getParameter("feedback");
	    
	    if(feedback != null) {
	    	int ok = itinDAO.updateFeedback(itinerioId, user.getId(), feedback);
	    	if (ok>0) {
	    		mesg ="Feedback inserito correttamente.";
	    		request.setAttribute("jsalert", mesg);
	    		request.setAttribute("type", "success");
	    	}else {
	    		mesg ="Problema nell inserimento del feedback";
	    		request.setAttribute("jsalert", mesg);
	    		request.setAttribute("type", "error");
	    	}
	    }
	    
	    String base64Image = user.getFoto();
	    
	    request.setAttribute("metodo", metodo);
	    request.setAttribute("itinerario", itinerario);
	    request.setAttribute("userI", userI);
	    request.setAttribute("button", button);
	    request.setAttribute("link", link);
	    request.setAttribute("fotoUserI", base64Image);
	    
	    RequestDispatcher dispatcher;
	    dispatcher = getServletContext().getRequestDispatcher("/dettagliI.jsp");
	    dispatcher.forward(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String button = request.getParameter("button");
		String feedback = request.getParameter("feedback");
	    
		request = UtilSession.setSession(request, getServletContext());
		User user = (User) request.getAttribute("user");
	    
		if(!button.isEmpty()) {
			String[] parts = button.split(";");
			String metodo = parts[0];
			String itinerarioID = parts[1];
			String userID = parts[2];
			
		    DAOFactory mysqlFactory = DAOFactory.getDAOFactory(DAOFactory.MYSQL);
			ItinerarioDAO itinDAO = mysqlFactory.getItinerarioDAO();
			UserDAO userDAO = mysqlFactory.getUserDAO();
			
			Itinerario itin = itinDAO.getItinerario(itinerarioID);
			User userIt = userDAO.getUserById(userID);
			
			request.setAttribute("itinerario", itin);
			request.setAttribute("userI", userIt);
			request.setAttribute("button", "");
			
			if(metodo.equalsIgnoreCase("prenota")) {
				int ok = itinDAO.createPrenotazione(Integer.parseInt(itinerarioID), Integer.parseInt(userID));
				if (ok>0) {
		    		String mesg ="Prenotazione effettata correttamente.";
		    		request.setAttribute("jsalert", mesg);
		    		request.setAttribute("type", "success");
		    		
				    RequestDispatcher dispatcher;
				    dispatcher = getServletContext().getRequestDispatcher("/dettagliI.jsp");
				    dispatcher.forward(request,response);
		    	}else {
		    		String mesg ="Problema nella prenotazione";
		    		request.setAttribute("jsalert", mesg);
		    		request.setAttribute("type", "error");
		    		
				    RequestDispatcher dispatcher;
				    dispatcher = getServletContext().getRequestDispatcher("/dettagliI.jsp");
				    dispatcher.forward(request,response);
		    	}
			} else if (metodo.equalsIgnoreCase("delete")) {
				int ok = itinDAO.deletePrenotazione(Integer.parseInt(itinerarioID), Integer.parseInt(userID));
				if (ok>0) {
		    		String mesg ="Prenotazione cancellata correttamente.";
		    		request.setAttribute("jsalert", mesg);
		    		request.setAttribute("type", "success");
		    		
				    RequestDispatcher dispatcher;
				    dispatcher = getServletContext().getRequestDispatcher("/dettagliI.jsp");
				    dispatcher.forward(request,response);
		    	}else {
		    		String mesg ="Problema nella cancellazione della prenotazione";
		    		request.setAttribute("jsalert", mesg);
		    		request.setAttribute("type", "error");
		    		
				    RequestDispatcher dispatcher;
				    dispatcher = getServletContext().getRequestDispatcher("/dettagliI.jsp");
				    dispatcher.forward(request,response);
		    	}
			}
		}
	}

}
